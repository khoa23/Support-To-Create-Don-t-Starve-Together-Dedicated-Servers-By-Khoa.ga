﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using IWshRuntimeLibrary;//https://stackoverflow.com/questions/4897655/create-a-shortcut-on-desktop
using System.IO;

namespace Support_to_create_DST_dedicated_server
{
    public partial class Home : Form
    {
        String cluster_number = "";// 440725477\Cluster_1
        String path_cluster_full = "";// C:\Users\user\Documents\Klei\DoNotStarveTogether\440725477\Cluster_1
        String path_cluster = "";// 440725477\Cluster_1
        String folderSteamApp = "";
        String listMods = "";
        String hostNameA = "";
        String descriptionA = "";
        String passwordA = "";
        String maxPlayerA = "";
        public Home()
        {
            InitializeComponent();
        }

        private void btnOpenFolderSteamApp_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "Choose Folder SteamApp";

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                string sSelectedPath = fbd.SelectedPath;
                lbFolderSteamApp.Text = sSelectedPath;
                folderSteamApp = sSelectedPath;
            }
        }

        private void btnOpenCluster_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "Choose Folder Cluster";
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                string sSelectedPath = fbd.SelectedPath; // C:\Users\user\Documents\Klei\DoNotStarveTogether\440725477\Cluster_1
                string cluster = sSelectedPath.Split("DoNotStarveTogether\\").Last(); // 440725477\Cluster_1
                cluster_number = cluster;// save cluster folder
                lbFolderCluster.Text = cluster;
                path_cluster_full = sSelectedPath;
                path_cluster = cluster;

                //show server info
                string pathCluster_ini = path_cluster_full + "\\cluster.ini";
                if (System.IO.File.Exists(pathCluster_ini))
                {
                    string fileCluster_ini = System.IO.File.ReadAllText(pathCluster_ini);
                    string hostName = FindTextBetween(fileCluster_ini, "cluster_name = ", "offline_cluster");
                    txtServerName.Text = hostName;
                    hostNameA = hostName;
                    string description = FindTextBetween(fileCluster_ini, "cluster_description = ", "cluster_name");
                    txtDescription.Text = description;
                    descriptionA = description;
                    string password = FindTextBetween(fileCluster_ini, "cluster_password = ", "cluster_description");
                    txtPassword.Text = password;
                    passwordA = password;
                    string maxPlayer = FindTextBetween(fileCluster_ini, "max_players = ", "pvp");
                    txtMaxPlayer.Text = maxPlayer;
                    maxPlayerA = maxPlayer;
                }
                else
                {
                    MessageBox.Show("Cluster empty", "Empty", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            //create cluster_token.txt file
            string path = path_cluster_full + "\\cluster_token.txt";
            //no exists - khong ton tai file cluster_token
            if (System.IO.File.Exists(path))
            {
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine(txtToken.Text);
                }
            }
            else if (!System.IO.File.Exists(path))
            {
                System.IO.File.Create(path).Dispose();
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine(txtToken.Text);
                }
            }
            //open file Cluster_test\Master\modoverrides.lua
            string pathModoverrride = path_cluster_full + "\\Master\\modoverrides.lua";
            string fileModOverride = System.IO.File.ReadAllText(pathModoverrride);

            //get list mod //["workshop-374550642;workshop-374550642"]
            var output = String.Join(";", Regex.Matches(fileModOverride, @"\[""(.+?)\""]")
                                    .Cast<Match>()
                                    .Select(m => m.Groups[1].Value));
            listMods = output;

            //copy mod
            lbStatus.Text = "Copying mod";
            String folderModsDST = folderSteamApp + "\\common\\Don't Starve Together\\mods\\";
            String folderModWorkshop = folderSteamApp + "\\workshop\\content\\322330\\";
            String folderModsDediDST = folderSteamApp + "\\common\\Don't Starve Together Dedicated Server\\mods\\";
            string[] split = listMods.Split(new Char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in split)
            {
                if (s.Trim() != "")
                {
                    //copy folder
                    if (!Directory.Exists(folderModsDST + s))//folderModWorkshop
                    {
                        string[] s1 = s.Split('-');
                        try
                        {
                            Copy(folderModWorkshop + s1[1], folderModsDediDST + s);
                        }
                        catch (FileNotFoundException exp)
                        {
                            MessageBox.Show("Folder " + s + " not found. Maybe it hasn't been downloaded yet\n" + exp, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {//folderModsDST
                        try
                        {
                            Copy(folderModsDST + s, folderModsDediDST + s);
                        }
                        catch (FileNotFoundException exp)
                        {
                            MessageBox.Show("Folder " + s + " not found. Maybe it hasn't been downloaded yet\n" + exp, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            //create .bat file
            string nameBat = "MyDedicatedServer";
            string batPath = folderSteamApp + "\\common\\Don't Starve Together Dedicated Server\\bin64\\" + "" + nameBat + ".bat";
            if (!System.IO.File.Exists(batPath))
            {
                System.IO.File.Create(batPath).Dispose();
                TextWriter tw = new StreamWriter(batPath);
                tw.WriteLine("c:\\steamcmd\\steamcmd.exe +login anonymous +app_update 343050 +quit\ncd /D \"%~dp0\"\nstart \"DST Server Master\" dontstarve_dedicated_server_nullrenderer_x64.exe -cluster " + path_cluster + " -shard Master \nstart \"DST Server Caves\" dontstarve_dedicated_server_nullrenderer_x64.exe -cluster " + path_cluster + " -shard Caves");
                tw.Close();
                CreateShortcut(nameBat);
                lbStatus.Text = "Done!!! Check " + nameBat + ".bat shortcut in your desktop";
            }
            else if (System.IO.File.Exists(batPath))
            {
                System.IO.File.Delete(batPath);
                using (var tw = new StreamWriter(batPath, true))
                {
                    tw.WriteLine("c:\\steamcmd\\steamcmd.exe +login anonymous +app_update 343050 +quit\ncd /D \"%~dp0\"\nstart \"DST Server Master\" dontstarve_dedicated_server_nullrenderer_x64.exe -cluster " + path_cluster + " -shard Master \nstart \"DST Server Caves\" dontstarve_dedicated_server_nullrenderer_x64.exe -cluster " + path_cluster + " -shard Caves");
                    CreateShortcut(nameBat);
                    lbStatus.Text = "Done!!! Check " + nameBat + ".bat shortcut in your Desktop";
                }
            }
        }

        public static void Copy(string sourceDirectory, string targetDirectory)
        {
            DirectoryInfo diSource = new DirectoryInfo(sourceDirectory);
            DirectoryInfo diTarget = new DirectoryInfo(targetDirectory);
            CopyAll(diSource, diTarget);
        }

        public static void CopyAll(DirectoryInfo source, DirectoryInfo target)
        {
            Directory.CreateDirectory(target.FullName);

            // Copy each file into the new directory.
            foreach (FileInfo fi in source.GetFiles())
            {
                fi.CopyTo(Path.Combine(target.FullName, fi.Name), true);
            }

            // Copy each subdirectory using recursion.
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                DirectoryInfo nextTargetSubDir =
                    target.CreateSubdirectory(diSourceSubDir.Name);
                CopyAll(diSourceSubDir, nextTargetSubDir);
            }
        }
        private void CreateShortcut(string name)
        {
            object shDesktop = (object)"Desktop";
            WshShell shell = new WshShell();
            string shortcutAddress = (string)shell.SpecialFolders.Item(ref shDesktop) + @"\" + name + ".lnk";
            IWshShortcut shortcut = (IWshShortcut)shell.CreateShortcut(shortcutAddress);
            shortcut.TargetPath = folderSteamApp + "\\common\\Don't Starve Together Dedicated Server\\bin64\\" + @"\" + name + ".bat";
            shortcut.Save();
        }

        public string FindTextBetween(string text, string left, string right)
        {
            // TODO: Validate input arguments

            int beginIndex = text.IndexOf(left); // find occurence of left delimiter
            if (beginIndex == -1)
                return string.Empty; // or throw exception?

            beginIndex += left.Length;

            int endIndex = text.IndexOf(right, beginIndex); // find occurence of right delimiter
            if (endIndex == -1)
                return string.Empty; // or throw exception?

            return text.Substring(beginIndex, endIndex - beginIndex).Trim();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string pathCluster_ini = System.IO.File.ReadAllText(path_cluster_full + "\\cluster.ini");

            pathCluster_ini = pathCluster_ini.Replace("cluster_name = " + hostNameA, "cluster_name = " + txtServerName.Text);
            System.IO.File.WriteAllText(path_cluster_full + "\\cluster.ini", pathCluster_ini);

            pathCluster_ini = pathCluster_ini.Replace("cluster_description = " + descriptionA, "cluster_description = " + txtDescription.Text);
            System.IO.File.WriteAllText(path_cluster_full + "\\cluster.ini", pathCluster_ini);

            pathCluster_ini = pathCluster_ini.Replace("cluster_password = " + passwordA, "cluster_password = " + txtPassword.Text);
            System.IO.File.WriteAllText(path_cluster_full + "\\cluster.ini", pathCluster_ini);

            pathCluster_ini = pathCluster_ini.Replace("max_players = " + maxPlayerA, "max_players = " + txtMaxPlayer.Text);
            System.IO.File.WriteAllText(path_cluster_full + "\\cluster.ini", pathCluster_ini);

            lbStatus.Text = "Saved!!!";
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.Show();
        }
    }
}
